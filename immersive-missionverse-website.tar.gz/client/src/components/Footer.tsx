import { FaTwitter, FaDiscord, FaGithub } from "react-icons/fa";

const quickLinks = [
  { name: "Current Missions", href: "#missions" },
  { name: "Join Faction", href: "#factions" },
  { name: "Technology", href: "#expo" },
  { name: "Environment", href: "#biosphere" },
];

const supportLinks = [
  { name: "Documentation", href: "#" },
  { name: "API Reference", href: "#" },
  { name: "Community", href: "#" },
  { name: "Contact", href: "#" },
];

export default function Footer() {
  const scrollToSection = (href: string) => {
    if (href.startsWith('#')) {
      const element = document.getElementById(href.substring(1));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  return (
    <footer className="bg-gray-800 py-16 border-t border-gray-700">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-yellow-400 to-yellow-500 flex items-center justify-center shadow-lg">
                <span className="text-gray-900 font-bold text-lg font-orbitron">CCCL</span>
              </div>
              <h4 className="text-2xl font-bold font-orbitron text-yellow-400">FREQUENT CCCL</h4>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed max-w-md">
              Join the immersive missionverse where imagination commands reality through advanced AR, AI, and satellite technologies.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors text-xl">
                <FaTwitter />
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors text-xl">
                <FaDiscord />
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-400 transition-colors text-xl">
                <FaGithub />
              </a>
            </div>
          </div>
          
          <div>
            <h5 className="font-bold mb-4 text-yellow-400">Quick Links</h5>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <button 
                    onClick={() => scrollToSection(link.href)}
                    className="text-gray-400 hover:text-white transition-colors text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h5 className="font-bold mb-4 text-yellow-400">Support</h5>
            <ul className="space-y-2">
              {supportLinks.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400">
          <p>&copy; 2025 FREQUENT CCCL. All rights reserved. | Immersive Missionverse Technology</p>
        </div>
      </div>
    </footer>
  );
}
