import { motion } from "framer-motion";
import { Leaf, Droplets, Sun } from "lucide-react";

const features = [
  {
    icon: Leaf,
    title: "Environmental Monitoring",
    description: "Real-time ecosystem health tracking through satellite networks and ground sensors.",
    color: "text-emerald-400"
  },
  {
    icon: Droplets,
    title: "Resource Conservation",
    description: "AI-driven optimization of natural resource usage and waste reduction protocols.",
    color: "text-blue-400"
  },
  {
    icon: Sun,
    title: "Sustainable Energy",
    description: "Solar-powered mission infrastructure with zero environmental impact.",
    color: "text-yellow-400"
  }
];

export default function BiosphereSection() {
  return (
    <section id="biosphere" className="py-24 bg-gray-900 relative">
      {/* Background image */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h3 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-4xl font-bold mb-8 text-yellow-400 font-orbitron"
          >
            Biosphere Integration
          </motion.h3>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-xl text-gray-300 mb-12 leading-relaxed"
          >
            The CCCL missionverse seamlessly integrates with natural ecosystems, creating a harmonious blend of technology and environmental consciousness.
          </motion.p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Earth from space showing environmental monitoring"
                className="rounded-xl shadow-2xl"
              />
            </motion.div>
            
            <div className="text-left space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-4"
                >
                  <div className={`${feature.color} text-2xl mt-1`}>
                    <feature.icon className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className={`text-lg font-bold mb-2 ${feature.color}`}>
                      {feature.title}
                    </h4>
                    <p className="text-gray-300">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
