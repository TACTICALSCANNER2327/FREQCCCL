import { motion } from "framer-motion";
import FactionCard from "./FactionCard";
import { factions } from "@/data/factions";
import { Globe } from "lucide-react";

export default function FactionsSection() {
  return (
    <section id="factions" className="py-24 bg-gray-900 relative">
      {/* Background image */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h3 className="text-4xl font-bold mb-4 text-yellow-400 font-orbitron">Operative Factions</h3>
          <p className="text-gray-300 text-xl max-w-3xl mx-auto leading-relaxed">
            Intelligence networks and specialized units operating within the CCCL missionverse. Align with a faction to access unique abilities and mission paths.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
          {factions.map((faction, index) => (
            <motion.div
              key={faction.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <FactionCard faction={faction} />
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <button className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-gray-900 font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-yellow-400/30 font-orbitron">
            <Globe className="w-5 h-5 mr-2 inline" />
            Explore All Factions
          </button>
        </motion.div>
      </div>
    </section>
  );
}
