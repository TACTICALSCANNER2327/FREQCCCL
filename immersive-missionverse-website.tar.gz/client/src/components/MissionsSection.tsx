import { motion } from "framer-motion";
import LiveFeed from "./LiveFeed";
import { Satellite, Code, Users, Check, Info } from "lucide-react";

export default function MissionsSection() {
  return (
    <section id="missions" className="py-24 bg-gray-800 relative">
      {/* Background image */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="lg:w-1/2 space-y-8"
          >
            <div>
              <h3 className="text-4xl font-bold mb-4 text-yellow-400 font-orbitron">
                Latest Mission: The Good Night Mayor
              </h3>
              <p className="text-gray-300 mb-8 text-lg leading-relaxed">
                Unravel a satellite signal virus that rewrites governance protocols. Mice-led meta-entities demand a hybrid system that bridges digital and physical realms.
              </p>
            </div>
            
            <div className="space-y-6">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                viewport={{ once: true }}
                className="flex items-start space-x-4 p-4 bg-gray-900/50 rounded-lg border border-gray-700"
              >
                <div className="text-yellow-400 mt-1 text-xl">
                  <Satellite className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-2">Signal Interference</h4>
                  <p className="text-gray-400">Track anomalous transmissions from the CCCL satellite array using advanced signal processing algorithms.</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
                className="flex items-start space-x-4 p-4 bg-gray-900/50 rounded-lg border border-gray-700"
              >
                <div className="text-yellow-400 mt-1 text-xl">
                  <Code className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-2">Protocol Decryption</h4>
                  <p className="text-gray-400">Decode the virus signature using AR interfaces and quantum computing resources.</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
                className="flex items-start space-x-4 p-4 bg-gray-900/50 rounded-lg border border-gray-700"
              >
                <div className="text-yellow-400 mt-1 text-xl">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-2">Faction Negotiation</h4>
                  <p className="text-gray-400">Establish diplomatic channels with MetaForcefield Mice and coordinate response strategies.</p>
                </div>
              </motion.div>
            </div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg">
                <Check className="w-5 h-5 mr-2 inline" />
                Accept Mission
              </button>
              <button className="border border-gray-500 text-gray-300 hover:bg-gray-700 font-medium py-3 px-8 rounded-lg transition-all duration-300">
                <Info className="w-5 h-5 mr-2 inline" />
                View Details
              </button>
            </motion.div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="lg:w-1/2"
          >
            <LiveFeed />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
