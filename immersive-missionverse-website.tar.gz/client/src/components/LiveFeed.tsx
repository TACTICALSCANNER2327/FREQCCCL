import { useState, useEffect } from "react";
import { motion } from "framer-motion";

interface SatelliteStatus {
  name: string;
  status: "ACTIVE" | "STANDBY" | "OFFLINE";
  color: string;
}

export default function LiveFeed() {
  const [progress, setProgress] = useState(78);
  
  const satelliteStatuses: SatelliteStatus[] = [
    { name: "Satellite Alpha", status: "ACTIVE", color: "text-green-400" },
    { name: "Satellite Beta", status: "STANDBY", color: "text-yellow-400" },
    { name: "Satellite Gamma", status: "OFFLINE", color: "text-red-400" },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        const change = (Math.random() - 0.5) * 2;
        return Math.min(100, Math.max(0, prev + change));
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative rounded-xl overflow-hidden border-2 border-blue-500/30 shadow-2xl shadow-blue-500/20 bg-gray-900">
      <div className="absolute top-4 right-4 bg-red-600 text-xs text-white px-3 py-1 rounded-full font-bold z-10">
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex items-center"
        >
          <div className="w-2 h-2 bg-white rounded-full mr-1" />
          LIVE FEED
        </motion.div>
      </div>
      
      <div className="p-8 h-96 flex flex-col">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block p-6 rounded-full bg-yellow-400/20 mb-6 relative">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <svg className="w-12 h-12 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" />
                  <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z" />
                </svg>
              </motion.div>
              <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-400 rounded-full">
                <motion.div
                  animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-full h-full bg-green-400 rounded-full"
                />
              </div>
            </div>
            
            <h4 className="text-xl font-bold mb-2 text-yellow-400">Signal Detected</h4>
            <p className="text-gray-400 mb-6">MetaForcefield Mice transmission intercepted</p>
            
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-400">Decryption Progress</span>
                <span className="text-sm font-bold text-yellow-400">{Math.round(progress)}%</span>
              </div>
              <div className="h-3 bg-gray-700 rounded-full overflow-hidden relative">
                <motion.div 
                  className="h-full bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full"
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5 }}
                />
                <div className="absolute inset-0 progress-bar" />
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-3 mt-6">
          {satelliteStatuses.map((satellite, index) => (
            <motion.div 
              key={satellite.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-gray-800/70 p-3 rounded-lg text-center backdrop-blur-sm border border-gray-700"
            >
              <div className={`${satellite.color} font-bold text-sm mb-1`}>
                <div className="w-2 h-2 bg-current rounded-full inline-block mr-1" />
                {satellite.status}
              </div>
              <div className="text-gray-400 text-xs">{satellite.name}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
