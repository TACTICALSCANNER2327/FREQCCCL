import { motion } from "framer-motion";

export default function SatelliteOrbit() {
  return (
    <div className="absolute inset-0 z-10">
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        {/* Outer orbit */}
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          className="w-80 h-80 border border-blue-500/30 rounded-full relative"
        >
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="w-3 h-3 bg-yellow-400 rounded-full satellite-dot" />
          </div>
        </motion.div>
        
        {/* Inner orbit */}
        <motion.div 
          animate={{ rotate: -360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="w-60 h-60 border border-yellow-400/20 rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
        >
          <div className="absolute top-1/4 right-0 transform translate-x-1/2 -translate-y-1/2">
            <motion.div 
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="w-2 h-2 bg-emerald-400 rounded-full"
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}
