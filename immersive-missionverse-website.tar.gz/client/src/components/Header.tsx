import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <header className="bg-gray-800/90 shadow-lg backdrop-blur-sm fixed w-full z-50 border-b border-yellow-400/20">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-yellow-400 to-yellow-500 flex items-center justify-center shadow-lg shadow-yellow-400/30">
            <span className="text-gray-900 font-bold text-sm font-orbitron">CCCL</span>
          </div>
          <h1 className="text-xl font-bold tracking-wider font-orbitron text-yellow-400">FREQUENT CCCL</h1>
        </div>
        
        <nav className="hidden md:flex space-x-8">
          <button onClick={() => scrollToSection('missions')} className="nav-link hover:text-yellow-300 transition-colors duration-300 font-medium">
            Missions
          </button>
          <button onClick={() => scrollToSection('factions')} className="nav-link hover:text-yellow-300 transition-colors duration-300 font-medium">
            Factions
          </button>
          <button onClick={() => scrollToSection('expo')} className="nav-link hover:text-yellow-300 transition-colors duration-300 font-medium">
            Expo
          </button>
          <button onClick={() => scrollToSection('biosphere')} className="nav-link hover:text-yellow-300 transition-colors duration-300 font-medium">
            Biosphere
          </button>
        </nav>
        
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden text-white p-2 rounded-lg hover:bg-gray-700 transition-colors"
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>
      
      {isMobileMenuOpen && (
        <div className="md:hidden bg-gray-800 border-t border-gray-700">
          <nav className="px-4 py-4 space-y-2">
            <button onClick={() => scrollToSection('missions')} className="block w-full text-left py-2 px-3 rounded-lg hover:bg-gray-700 transition-colors">
              Missions
            </button>
            <button onClick={() => scrollToSection('factions')} className="block w-full text-left py-2 px-3 rounded-lg hover:bg-gray-700 transition-colors">
              Factions
            </button>
            <button onClick={() => scrollToSection('expo')} className="block w-full text-left py-2 px-3 rounded-lg hover:bg-gray-700 transition-colors">
              Expo
            </button>
            <button onClick={() => scrollToSection('biosphere')} className="block w-full text-left py-2 px-3 rounded-lg hover:bg-gray-700 transition-colors">
              Biosphere
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
