import { motion } from "framer-motion";

const technologies = [
  {
    title: "Quantum Satellites",
    description: "Advanced quantum communication satellites enabling instantaneous data transfer across dimensional barriers.",
    image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    color: "text-yellow-400"
  },
  {
    title: "AR Interfaces",
    description: "Immersive augmented reality systems for real-time mission coordination and environmental analysis.",
    image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    color: "text-emerald-400"
  },
  {
    title: "AI Consciousness",
    description: "Self-evolving artificial intelligence systems capable of independent decision-making and learning.",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    color: "text-blue-400"
  }
];

export default function ExpoSection() {
  return (
    <section id="expo" className="py-24 bg-gray-800 relative">
      {/* Background image */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1517976547714-720226b864c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h3 className="text-4xl font-bold mb-4 text-yellow-400 font-orbitron">Technology Expo</h3>
          <p className="text-gray-300 text-xl max-w-3xl mx-auto leading-relaxed">
            Cutting-edge AR, AI, and satellite technologies powering the CCCL missionverse.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {technologies.map((tech, index) => (
            <motion.div
              key={tech.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              className="bg-gray-900/70 rounded-xl p-8 border border-gray-700 hover:border-yellow-400/50 transition-all duration-300 backdrop-blur-sm"
            >
              <div className="mb-6 rounded-lg overflow-hidden">
                <img 
                  src={tech.image} 
                  alt={tech.title}
                  className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <h4 className={`text-xl font-bold mb-3 ${tech.color} font-orbitron`}>
                {tech.title}
              </h4>
              <p className="text-gray-300 leading-relaxed">
                {tech.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
