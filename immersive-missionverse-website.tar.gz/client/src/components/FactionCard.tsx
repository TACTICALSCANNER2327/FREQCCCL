import { motion } from "framer-motion";
import { 
  FaMousePointer, 
  FaTree, 
  FaDove, 
  FaDog, 
  FaCat, 
  FaFish,
  FaBug, 
  FaDragon,
  FaStar,
  FaShieldAlt
} from "react-icons/fa";

interface Faction {
  id: number;
  name: string;
  description: string;
  icon: string;
  color: string;
  influence: number;
  members: number;
  active: number;
}

interface FactionCardProps {
  faction: Faction;
}

const iconMap = {
  mouse: FaMousePointer,
  tree: FaTree,
  bird: FaDove,
  dog: FaDog,
  cat: FaCat,
  ferret: FaFish,
  bug: FaBug,
  snake: FaDragon,
  star: FaStar,
  shell: FaShieldAlt,
};

export default function FactionCard({ faction }: FactionCardProps) {
  const IconComponent = iconMap[faction.icon as keyof typeof iconMap] || FaMousePointer;
  
  const getColorClasses = (color: string) => {
    const colorMap: Record<string, any> = {
      yellow: {
        border: "border-yellow-500/30 hover:border-yellow-400/50",
        bg: "bg-gradient-to-b from-yellow-400/20 to-yellow-400/10",
        iconBg: "bg-yellow-400/30",
        text: "text-yellow-400",
        progress: "bg-gradient-to-r from-yellow-400 to-yellow-500"
      },
      emerald: {
        border: "border-emerald-500/30 hover:border-emerald-400/50",
        bg: "bg-gradient-to-b from-emerald-400/20 to-emerald-400/10",
        iconBg: "bg-emerald-400/30",
        text: "text-emerald-400",
        progress: "bg-gradient-to-r from-emerald-400 to-emerald-500"
      },
      blue: {
        border: "border-blue-500/30 hover:border-blue-400/50",
        bg: "bg-gradient-to-b from-blue-400/20 to-blue-400/10",
        iconBg: "bg-blue-400/30",
        text: "text-blue-400",
        progress: "bg-gradient-to-r from-blue-400 to-blue-500"
      },
      purple: {
        border: "border-purple-500/30 hover:border-purple-400/50",
        bg: "bg-gradient-to-b from-purple-400/20 to-purple-400/10",
        iconBg: "bg-purple-400/30",
        text: "text-purple-400",
        progress: "bg-gradient-to-r from-purple-400 to-purple-500"
      },
      orange: {
        border: "border-orange-500/30 hover:border-orange-400/50",
        bg: "bg-gradient-to-b from-orange-400/20 to-orange-400/10",
        iconBg: "bg-orange-400/30",
        text: "text-orange-400",
        progress: "bg-gradient-to-r from-orange-400 to-orange-500"
      },
      gray: {
        border: "border-gray-500/30 hover:border-gray-400/50",
        bg: "bg-gradient-to-b from-gray-400/20 to-gray-400/10",
        iconBg: "bg-gray-400/30",
        text: "text-gray-400",
        progress: "bg-gradient-to-r from-gray-400 to-gray-500"
      },
      green: {
        border: "border-green-500/30 hover:border-green-400/50",
        bg: "bg-gradient-to-b from-green-400/20 to-green-400/10",
        iconBg: "bg-green-400/30",
        text: "text-green-400",
        progress: "bg-gradient-to-r from-green-400 to-green-500"
      },
      violet: {
        border: "border-violet-500/30 hover:border-violet-400/50",
        bg: "bg-gradient-to-b from-violet-400/20 to-violet-400/10",
        iconBg: "bg-violet-400/30",
        text: "text-violet-400",
        progress: "bg-gradient-to-r from-violet-400 to-violet-500"
      },
      amber: {
        border: "border-amber-500/30 hover:border-amber-400/50",
        bg: "bg-gradient-to-b from-amber-400/20 to-amber-400/10",
        iconBg: "bg-amber-400/30",
        text: "text-amber-400",
        progress: "bg-gradient-to-r from-amber-400 to-amber-500"
      }
    };
    return colorMap[color] || colorMap.yellow;
  };

  const colors = getColorClasses(faction.color);

  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={`faction-card bg-gray-800 rounded-xl shadow-xl overflow-hidden border-2 ${colors.border} cursor-pointer`}
    >
      <div className={`${colors.bg} p-6 text-center`}>
        <div className={`inline-block p-4 rounded-full ${colors.iconBg} mb-4 transition-colors`}>
          <IconComponent className={`${colors.text} text-2xl`} />
        </div>
        <h4 className={`font-bold ${colors.text} text-lg font-orbitron`}>{faction.name}</h4>
      </div>
      
      <div className="p-6">
        <p className="text-gray-300 text-sm mb-6 leading-relaxed">{faction.description}</p>
        
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Influence</span>
            <span className={`${colors.text} font-bold`}>{faction.influence}%</span>
          </div>
          
          <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
            <motion.div 
              className={`h-full ${colors.progress} rounded-full`}
              initial={{ width: 0 }}
              whileInView={{ width: `${faction.influence}%` }}
              transition={{ duration: 1, delay: 0.2 }}
              viewport={{ once: true }}
            />
          </div>
          
          <div className="flex justify-between text-sm text-gray-400">
            <span>Members: <span className="text-white">{faction.members}</span></span>
            <span>Active: <span className="text-white">{faction.active}</span></span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
