import { motion } from "framer-motion";
import SatelliteOrbit from "./SatelliteOrbit";
import { Rocket, Users } from "lucide-react";

export default function HeroSection() {
  const handleJoinMission = () => {
    const element = document.getElementById('missions');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleExploreFactions = () => {
    const element = document.getElementById('factions');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center pt-16 relative overflow-hidden bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900">
      {/* Background image */}
      <div 
        className="absolute inset-0 z-0 opacity-10"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      {/* Grid pattern */}
      <div className="absolute inset-0 grid-pattern opacity-30" />
      
      {/* Satellite orbit animation */}
      <SatelliteOrbit />

      <div className="container mx-auto px-4 text-center relative z-20">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="text-5xl md:text-6xl lg:text-7xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-400 to-yellow-500 font-orbitron"
        >
          Where Imagination Commands Reality
        </motion.h2>
        
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-12 leading-relaxed"
        >
          An immersive missionverse linking AR, AI, and real-world satellite experiences in the CCCL region.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="flex flex-col md:flex-row gap-6 justify-center items-center"
        >
          <button 
            onClick={handleJoinMission}
            className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-gray-900 font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-yellow-400/30 font-orbitron"
          >
            <Rocket className="w-5 h-5 mr-2 inline" />
            Join Current Mission
          </button>
          
          <button 
            onClick={handleExploreFactions}
            className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 font-bold py-4 px-8 rounded-lg transition-all duration-300 backdrop-blur-sm"
          >
            <Users className="w-5 h-5 mr-2 inline" />
            Explore Factions
          </button>
        </motion.div>
      </div>
    </section>
  );
}
