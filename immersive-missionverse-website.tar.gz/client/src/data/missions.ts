export const currentMission = {
  id: 1,
  title: "The Good Night Mayor",
  description: "Unravel a satellite signal virus that rewrites governance protocols. Mice-led meta-entities demand a hybrid system that bridges digital and physical realms.",
  status: "active",
  progress: 78,
  objectives: [
    {
      title: "Signal Interference",
      description: "Track anomalous transmissions from the CCCL satellite array using advanced signal processing algorithms.",
      icon: "satellite"
    },
    {
      title: "Protocol Decryption",
      description: "Decode the virus signature using AR interfaces and quantum computing resources.",
      icon: "code"
    },
    {
      title: "Faction Negotiation",
      description: "Establish diplomatic channels with MetaForcefield Mice and coordinate response strategies.",
      icon: "users"
    }
  ]
};
