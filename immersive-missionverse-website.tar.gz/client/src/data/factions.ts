export const factions = [
  {
    id: 1,
    name: "MetaForcefield Mice",
    description: "Lab escapees turned signal hackers. Lead faction in the current mission.",
    icon: "mouse",
    color: "yellow",
    influence: 92,
    members: 247,
    active: 89
  },
  {
    id: 2,
    name: "National Squirrel Agency",
    description: "Tree intel unit. Offers NSA internships to youth operatives.",
    icon: "tree",
    color: "emerald",
    influence: 78,
    members: 183,
    active: 67
  },
  {
    id: 3,
    name: "AVIARYO",
    description: "Sky surveillance, drone birds, and feathered operatives.",
    icon: "bird",
    color: "blue",
    influence: 65,
    members: 129,
    active: 45
  },
  {
    id: 4,
    name: "MK9 ULTRA",
    description: "Canine memory warriors guarding dream frequencies.",
    icon: "dog",
    color: "purple",
    influence: 71,
    members: 156,
    active: 78
  },
  {
    id: 5,
    name: "MiCAT5",
    description: "Stealth feline agents controlling data grids.",
    icon: "cat",
    color: "orange",
    influence: 83,
    members: 201,
    active: 94
  },
  {
    id: 6,
    name: "Ferret X",
    description: "Tunnelers, engineers, and mischief-makers of the underground.",
    icon: "ferret",
    color: "gray",
    influence: 59,
    members: 112,
    active: 34
  },
  {
    id: 7,
    name: "Insecta Syndicate",
    description: "Micro-infiltrators who control bio-intelligence.",
    icon: "bug",
    color: "green",
    influence: 68,
    members: 342,
    active: 156
  },
  {
    id: 8,
    name: "Reptilian Cipher",
    description: "Cold-blooded tacticians with ancient satellite wisdom.",
    icon: "snake",
    color: "emerald",
    influence: 74,
    members: 98,
    active: 67
  },
  {
    id: 9,
    name: "OPHIUCHUS Division 13",
    description: "Starseed investigators of the zodiac continuum.",
    icon: "star",
    color: "violet",
    influence: 87,
    members: 113,
    active: 89
  },
  {
    id: 10,
    name: "Terra Shell Intelligence",
    description: "Geo-protectors monitoring tectonic disruptions.",
    icon: "shell",
    color: "amber",
    influence: 62,
    members: 89,
    active: 23
  }
];
