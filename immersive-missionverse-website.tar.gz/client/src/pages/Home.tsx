import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import MissionsSection from "@/components/MissionsSection";
import FactionsSection from "@/components/FactionsSection";
import ExpoSection from "@/components/ExpoSection";
import BiosphereSection from "@/components/BiosphereSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <MissionsSection />
        <FactionsSection />
        <ExpoSection />
        <BiosphereSection />
      </main>
      <Footer />
    </div>
  );
}
