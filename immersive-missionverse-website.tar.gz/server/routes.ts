import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMissionSchema, insertFactionSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Mission routes
  app.get("/api/missions", async (req, res) => {
    try {
      const missions = await storage.getMissions();
      res.json(missions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch missions" });
    }
  });

  app.get("/api/missions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const mission = await storage.getMission(id);
      
      if (!mission) {
        return res.status(404).json({ message: "Mission not found" });
      }
      
      res.json(mission);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mission" });
    }
  });

  app.post("/api/missions", async (req, res) => {
    try {
      const validatedData = insertMissionSchema.parse(req.body);
      const mission = await storage.createMission(validatedData);
      res.status(201).json(mission);
    } catch (error) {
      res.status(400).json({ message: "Invalid mission data" });
    }
  });

  app.patch("/api/missions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const mission = await storage.updateMission(id, req.body);
      
      if (!mission) {
        return res.status(404).json({ message: "Mission not found" });
      }
      
      res.json(mission);
    } catch (error) {
      res.status(500).json({ message: "Failed to update mission" });
    }
  });

  // Faction routes
  app.get("/api/factions", async (req, res) => {
    try {
      const factions = await storage.getFactions();
      res.json(factions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch factions" });
    }
  });

  app.get("/api/factions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const faction = await storage.getFaction(id);
      
      if (!faction) {
        return res.status(404).json({ message: "Faction not found" });
      }
      
      res.json(faction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch faction" });
    }
  });

  app.post("/api/factions", async (req, res) => {
    try {
      const validatedData = insertFactionSchema.parse(req.body);
      const faction = await storage.createFaction(validatedData);
      res.status(201).json(faction);
    } catch (error) {
      res.status(400).json({ message: "Invalid faction data" });
    }
  });

  app.patch("/api/factions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const faction = await storage.updateFaction(id, req.body);
      
      if (!faction) {
        return res.status(404).json({ message: "Faction not found" });
      }
      
      res.json(faction);
    } catch (error) {
      res.status(500).json({ message: "Failed to update faction" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
