import { users, missions, factions, type User, type InsertUser, type Mission, type InsertMission, type Faction, type InsertFaction } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getMissions(): Promise<Mission[]>;
  getMission(id: number): Promise<Mission | undefined>;
  createMission(mission: InsertMission): Promise<Mission>;
  updateMission(id: number, mission: Partial<Mission>): Promise<Mission | undefined>;
  getFactions(): Promise<Faction[]>;
  getFaction(id: number): Promise<Faction | undefined>;
  createFaction(faction: InsertFaction): Promise<Faction>;
  updateFaction(id: number, faction: Partial<Faction>): Promise<Faction | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private missions: Map<number, Mission>;
  private factions: Map<number, Faction>;
  private currentUserId: number;
  private currentMissionId: number;
  private currentFactionId: number;

  constructor() {
    this.users = new Map();
    this.missions = new Map();
    this.factions = new Map();
    this.currentUserId = 1;
    this.currentMissionId = 1;
    this.currentFactionId = 1;
    
    // Initialize with default data
    this.initializeData();
  }

  private initializeData() {
    // Initialize factions
    const defaultFactions = [
      { name: "MetaForcefield Mice", description: "Lab escapees turned signal hackers. Lead faction in the current mission.", icon: "mouse", color: "yellow", influence: 92, members: 247, active: 89 },
      { name: "National Squirrel Agency", description: "Tree intel unit. Offers NSA internships to youth operatives.", icon: "tree", color: "emerald", influence: 78, members: 183, active: 67 },
      { name: "AVIARYO", description: "Sky surveillance, drone birds, and feathered operatives.", icon: "bird", color: "blue", influence: 65, members: 129, active: 45 },
      { name: "MK9 ULTRA", description: "Canine memory warriors guarding dream frequencies.", icon: "dog", color: "purple", influence: 71, members: 156, active: 78 },
      { name: "MiCAT5", description: "Stealth feline agents controlling data grids.", icon: "cat", color: "orange", influence: 83, members: 201, active: 94 },
      { name: "Ferret X", description: "Tunnelers, engineers, and mischief-makers of the underground.", icon: "ferret", color: "gray", influence: 59, members: 112, active: 34 },
      { name: "Insecta Syndicate", description: "Micro-infiltrators who control bio-intelligence.", icon: "bug", color: "green", influence: 68, members: 342, active: 156 },
      { name: "Reptilian Cipher", description: "Cold-blooded tacticians with ancient satellite wisdom.", icon: "snake", color: "emerald", influence: 74, members: 98, active: 67 },
      { name: "OPHIUCHUS Division 13", description: "Starseed investigators of the zodiac continuum.", icon: "star", color: "violet", influence: 87, members: 113, active: 89 },
      { name: "Terra Shell Intelligence", description: "Geo-protectors monitoring tectonic disruptions.", icon: "shell", color: "amber", influence: 62, members: 89, active: 23 }
    ];

    defaultFactions.forEach(faction => this.createFaction(faction));

    // Initialize current mission
    this.createMission({
      title: "The Good Night Mayor",
      description: "Unravel a satellite signal virus that rewrites governance protocols",
      status: "active",
      progress: 78,
      factionId: 1
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMissions(): Promise<Mission[]> {
    return Array.from(this.missions.values());
  }

  async getMission(id: number): Promise<Mission | undefined> {
    return this.missions.get(id);
  }

  async createMission(insertMission: InsertMission): Promise<Mission> {
    const id = this.currentMissionId++;
    const mission: Mission = { ...insertMission, id };
    this.missions.set(id, mission);
    return mission;
  }

  async updateMission(id: number, updates: Partial<Mission>): Promise<Mission | undefined> {
    const mission = this.missions.get(id);
    if (!mission) return undefined;
    
    const updatedMission = { ...mission, ...updates };
    this.missions.set(id, updatedMission);
    return updatedMission;
  }

  async getFactions(): Promise<Faction[]> {
    return Array.from(this.factions.values());
  }

  async getFaction(id: number): Promise<Faction | undefined> {
    return this.factions.get(id);
  }

  async createFaction(insertFaction: InsertFaction): Promise<Faction> {
    const id = this.currentFactionId++;
    const faction: Faction = { ...insertFaction, id };
    this.factions.set(id, faction);
    return faction;
  }

  async updateFaction(id: number, updates: Partial<Faction>): Promise<Faction | undefined> {
    const faction = this.factions.get(id);
    if (!faction) return undefined;
    
    const updatedFaction = { ...faction, ...updates };
    this.factions.set(id, updatedFaction);
    return updatedFaction;
  }
}

export const storage = new MemStorage();
